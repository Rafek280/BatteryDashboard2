package de.frauas.informatik.batterydashboard.dataSync;



public class User {

    String username;
    String id;
    void set_id(String id){

}

String get_id(){
    return id;
}

    void setUsername(String username){

    }

    String getUsername(){

    return username;
    }

}
